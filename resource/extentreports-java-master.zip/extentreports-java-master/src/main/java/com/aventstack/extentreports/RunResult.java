package com.aventstack.extentreports;

public interface RunResult {
    Status getStatus();
}
