package com.aventstack.extentreports.model;

public enum MediaType {
    IMG,
    VID
}
