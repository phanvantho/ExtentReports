package com.aventstack.extentreports.markuputils;

@FunctionalInterface
public interface Markup {
    String getMarkup();
}
