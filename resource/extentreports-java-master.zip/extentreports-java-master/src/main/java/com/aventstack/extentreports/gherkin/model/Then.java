package com.aventstack.extentreports.gherkin.model;

public class Then implements IGherkinFormatterModel {

}
