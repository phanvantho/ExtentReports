package com.aventstack.extentreports.reporter;

public interface ReportAppendable {
    void setAppendExisting(Boolean b);
}
