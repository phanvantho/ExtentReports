package com.aventstack.extentreports.reporter.configuration;

public interface IReporterConfiguration { }
