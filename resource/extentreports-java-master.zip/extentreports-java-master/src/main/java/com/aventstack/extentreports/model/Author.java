package com.aventstack.extentreports.model;

public class Author extends TestAttribute {

    static final long serialVersionUID = 5358337504569462439L;

    public Author(String k) {
        super(k);
    }
    
}
