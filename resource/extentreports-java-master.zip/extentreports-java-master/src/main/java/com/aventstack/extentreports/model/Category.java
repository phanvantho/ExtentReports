package com.aventstack.extentreports.model;

public class Category extends TestAttribute {

    static final long serialVersionUID = -7850780488330456977L;

    public Category(String k) {
        super(k);
    }
    
}
