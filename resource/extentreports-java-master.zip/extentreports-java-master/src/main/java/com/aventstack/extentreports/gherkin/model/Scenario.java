package com.aventstack.extentreports.gherkin.model;

public class Scenario implements IGherkinFormatterModel {

}
